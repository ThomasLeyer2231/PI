<?php 
logout();
header('Location: /');
?>